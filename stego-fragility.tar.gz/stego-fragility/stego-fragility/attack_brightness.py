import cv2
import numpy as np

cap = cv2.VideoCapture("stego_original.mp4")
fps = cap.get(cv2.CAP_PROP_FPS)
width, height = int(cap.get(3)), int(cap.get(4))
out = cv2.VideoWriter("stego_brightness.mp4", cv2.VideoWriter_fourcc(*'mp4v'), fps, (width, height))

while True:
    ret, frame = cap.read()
    if not ret: break
    # Tăng 10 giá trị pixel, dùng np.clip để không vượt quá 255
    bright = np.clip(frame.astype(int) + 10, 0, 255).astype(np.uint8)
    out.write(bright)
out.release()
