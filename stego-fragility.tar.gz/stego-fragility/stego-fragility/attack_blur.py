import cv2
cap = cv2.VideoCapture("stego_original.mp4")
fps = cap.get(cv2.CAP_PROP_FPS)
width, height = int(cap.get(3)), int(cap.get(4))
out = cv2.VideoWriter("stego_blur.mp4", cv2.VideoWriter_fourcc(*'mp4v'), fps, (width, height))

while True:
    ret, frame = cap.read()
    if not ret: break
    # Làm mờ Gaussian 3x3
    blurred = cv2.GaussianBlur(frame, (3, 3), 0)
    out.write(blurred)
out.release()
