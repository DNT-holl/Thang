import cv2
import numpy as np
import sys

def extract_message(stego_video):
    cap = cv2.VideoCapture(stego_video)
    if not cap.isOpened():
        print("Lỗi: Không thể mở video.")
        sys.exit(1)

    delta = 16
    extracted_bits = ""
    print(f"Đang trích xuất dữ liệu từ {stego_video}...")

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        ycrcb = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
        Y, _, _ = cv2.split(ycrcb)

        h_trunc = Y.shape[0] - (Y.shape[0] % 8)
        w_trunc = Y.shape[1] - (Y.shape[1] % 8)

        for i in range(0, h_trunc, 8):
            for j in range(0, w_trunc, 8):
                block = np.float32(Y[i:i+8, j:j+8])
                dct_block = cv2.dct(block)
                
                dc_val = dct_block[0, 0]
                quantized = np.round(dc_val / delta) * delta
                
                # Giải mã QIM
                if dc_val > quantized:
                    extracted_bits += '1'
                else:
                    extracted_bits += '0'
                    
        # Để tránh chạy vô hạn, giả sử ta chỉ đọc khoảng 100 ký tự (800 bits) đầu tiên để test
        if len(extracted_bits) > 800:
            break
            
    cap.release()

    # Chuyển bit thành chuỗi văn bản
    chars = []
    for i in range(0, len(extracted_bits), 8):
        byte = extracted_bits[i:i+8]
        if len(byte) == 8:
            chars.append(chr(int(byte, 2)))
            
    message = "".join(chars)
    print("\n[+] THÔNG ĐIỆP TRÍCH XUẤT ĐƯỢC:")
    print(message[:100] + "...") # In 100 ký tự đầu

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Sử dụng: python3 stego_extract.py <video_stego>")
        sys.exit(1)
    extract_message(sys.argv[1])
