import cv2
import numpy as np

def add_salt_and_pepper_noise(frame, noise_ratio=0.01):
    """
    Hàm thêm nhiễu Salt & Pepper vào khung hình.
    :param frame: Khung hình gốc
    :param noise_ratio: Tỷ lệ nhiễu (mặc định 1%)
    """
    noisy = np.copy(frame)
    row, col, _ = noisy.shape
    
    # Tạo một ma trận ngẫu nhiên có cùng kích thước (chiều rộng x chiều cao)
    # Ma trận này chứa các giá trị từ 0.0 đến 1.0
    rand_matrix = np.random.rand(row, col)
    
    # Thêm nhiễu Muối (Trắng - 255) cho các pixel có giá trị ngẫu nhiên rất nhỏ
    noisy[rand_matrix < (noise_ratio / 2)] = 255
    
    # Thêm nhiễu Tiêu (Đen - 0) cho các pixel có giá trị ngẫu nhiên rất lớn
    noisy[rand_matrix > (1 - noise_ratio / 2)] = 0
    
    return noisy

def main():
    cap = cv2.VideoCapture("stego_original.mp4")
    if not cap.isOpened():
        print("Lỗi: Không tìm thấy file stego_original.mp4")
        return

    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter("stego_noise.mp4", fourcc, fps, (width, height))

    print("Đang thêm nhiễu Salt & Pepper vào video...")

    while True:
        ret, frame = cap.read()
        if not ret: 
            break
            
        # Áp dụng nhiễu với tỷ lệ 1% trên mỗi khung hình
        noisy_frame = add_salt_and_pepper_noise(frame, noise_ratio=0.01)
        out.write(noisy_frame)

    cap.release()
    out.release()
    print("Hoàn tất! Video đã được lưu tại stego_noise.mp4")

if __name__ == "__main__":
    main()
