import cv2
import numpy as np
import sys

def extract_watermark(stego_video, output_logo_path, logo_size=64):
    cap = cv2.VideoCapture(stego_video)
    if not cap.isOpened():
        print("Lỗi: Không thể mở video.")
        sys.exit(1)

    total_bits = logo_size * logo_size
    extracted_bits = []

    print(f"Đang trích xuất {total_bits} bits từ video...")

    while True:
        ret, frame = cap.read()
        if not ret or len(extracted_bits) >= total_bits:
            break

        ycrcb = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
        Y, _, _ = cv2.split(ycrcb)

        h_trunc = Y.shape[0] - (Y.shape[0] % 8)
        w_trunc = Y.shape[1] - (Y.shape[1] % 8)

        for i in range(0, h_trunc, 8):
            for j in range(0, w_trunc, 8):
                if len(extracted_bits) >= total_bits:
                    break

                block = np.float32(Y[i:i+8, j:j+8])
                dct_block = cv2.dct(block)
                
                dc_val = round(dct_block[0, 0])
                
                # Giải mã: Chẵn -> 1, Lẻ -> 0
                if dc_val % 2 == 0:
                    extracted_bits.append(1)
                else:
                    extracted_bits.append(0)

    cap.release()

    if len(extracted_bits) < total_bits:
        print("Cảnh báo: Không đủ dữ liệu để khôi phục toàn bộ ảnh.")
    
    # Chuyển đổi lại thành ma trận 2D
    extracted_array = np.array(extracted_bits[:total_bits], dtype=np.uint8)
    watermark_img = extracted_array.reshape((logo_size, logo_size))
    
    # Nhân với 255 để chuyển từ nhị phân (0,1) sang màu pixel đen trắng chuẩn (0, 255)
    cv2.imwrite(output_logo_path, watermark_img * 255)
    print(f"Trích xuất thành công! Ảnh lưu tại: {output_logo_path}")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Sử dụng: python3 watermark_extract.py <video_stego> <logo_output.png>")
        sys.exit(1)
    extract_watermark(sys.argv[1], sys.argv[2])
