import cv2
import numpy as np
import sys

def evaluate_recovery(original_logo_path, extracted_logo_path):
    orig = cv2.imread(original_logo_path, cv2.IMREAD_GRAYSCALE)
    extr = cv2.imread(extracted_logo_path, cv2.IMREAD_GRAYSCALE)

    if orig is None or extr is None:
        print("Lỗi: Không thể đọc file ảnh.")
        sys.exit(1)

    if orig.shape != extr.shape:
        print("Lỗi: Kích thước hai ảnh không khớp.")
        sys.exit(1)

    # Đưa cả 2 về dạng 0 và 1 để so sánh
    _, orig_bin = cv2.threshold(orig, 127, 1, cv2.THRESH_BINARY)
    _, extr_bin = cv2.threshold(extr, 127, 1, cv2.THRESH_BINARY)

    # Tính toán số lượng pixel giống nhau
    total_pixels = orig.shape[0] * orig.shape[1]
    matching_pixels = np.sum(orig_bin == extr_bin)
    
    match_rate = (matching_pixels / total_pixels) * 100

    print("--- KẾT QUẢ ĐÁNH GIÁ ---")
    print(f"Tổng số pixel: {total_pixels}")
    print(f"Số pixel khớp: {matching_pixels}")
    print(f"Tỷ lệ chính xác: {match_rate:.2f}%")
    
    if match_rate >= 95.0:
        print("ĐÁNH GIÁ: ĐẠT YÊU CẦU (>95%)")
    else:
        print("ĐÁNH GIÁ: KHÔNG ĐẠT YÊU CẦU")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Sử dụng: python3 watermark_eval.py <logo_goc> <logo_trichxuat>")
        sys.exit(1)
    evaluate_recovery(sys.argv[1], sys.argv[2])
