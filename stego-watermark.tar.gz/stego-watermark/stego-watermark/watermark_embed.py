import cv2
import numpy as np
import sys
import os

def embed_watermark(video_path, logo_path, output_path):
    if not os.path.exists(logo_path) or not os.path.exists(video_path):
        print("Lỗi: Không tìm thấy file video hoặc file ảnh logo.")
        sys.exit(1)

    # Đọc ảnh logo dưới dạng đen trắng
    logo = cv2.imread(logo_path, cv2.IMREAD_GRAYSCALE)
    
    # Ép về nhị phân (0 hoặc 1)
    _, binary_logo = cv2.threshold(logo, 127, 1, cv2.THRESH_BINARY)
    
    # Trải phẳng ảnh thành mảng 1 chiều (4096 bit cho ảnh 64x64)
    bits = binary_logo.flatten()
    bit_len = len(bits)
    bit_idx = 0

    cap = cv2.VideoCapture(video_path)
    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))

    print(f"Đang nhúng {bit_len} bits watermark vào video...")

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        if bit_idx < bit_len:
            ycrcb = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
            Y, Cr, Cb = cv2.split(ycrcb)

            h_trunc = Y.shape[0] - (Y.shape[0] % 8)
            w_trunc = Y.shape[1] - (Y.shape[1] % 8)

            for i in range(0, h_trunc, 8):
                for j in range(0, w_trunc, 8):
                    if bit_idx >= bit_len:
                        break

                    block = np.float32(Y[i:i+8, j:j+8])
                    dct_block = cv2.dct(block)

                    # Lấy hệ số DC và làm tròn
                    dc_val = round(dct_block[0, 0])
                    bit = bits[bit_idx]

                    # Quy tắc Chẵn/Lẻ
                    # Bit 1 -> DC phải là số chẵn
                    if bit == 1 and dc_val % 2 != 0:
                        dc_val += 1
                    # Bit 0 -> DC phải là số lẻ
                    elif bit == 0 and dc_val % 2 == 0:
                        dc_val += 1

                    dct_block[0, 0] = dc_val
                    bit_idx += 1

                    idct_block = cv2.idct(dct_block)
                    Y[i:i+8, j:j+8] = np.clip(idct_block, 0, 255)

            merged = cv2.merge([Y, Cr, Cb])
            frame = cv2.cvtColor(merged, cv2.COLOR_YCrCb2BGR)
            
        out.write(frame)

    cap.release()
    out.release()
    print(f"Hoàn tất! Video đã được lưu tại {output_path}")

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Sử dụng: python3 watermark_embed.py <video_goc> <logo_nhiphan> <video_output>")
        sys.exit(1)
    embed_watermark(sys.argv[1], sys.argv[2], sys.argv[3])
