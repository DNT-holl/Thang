import cv2
import numpy as np
from skimage.metrics import peak_signal_noise_ratio as compare_psnr
from skimage.metrics import structural_similarity as compare_ssim
import sys

def calculate_video_metrics(original_video_path, stego_video_path):
    """
    Hàm tính toán giá trị PSNR và SSIM trung bình giữa 2 video.
    """
    # Mở 2 luồng video
    cap_orig = cv2.VideoCapture(original_video_path)
    cap_stego = cv2.VideoCapture(stego_video_path)

    if not cap_orig.isOpened() or not cap_stego.isOpened():
        print("Lỗi: Không thể mở một trong hai video. Hãy kiểm tra lại đường dẫn!")
        return None, None, 0

    total_psnr = 0.0
    total_ssim = 0.0
    frame_count = 0

    while True:
        ret_orig, frame_orig = cap_orig.read()
        ret_stego, frame_stego = cap_stego.read()

        # Dừng vòng lặp nếu 1 trong 2 video kết thúc
        if not ret_orig or not ret_stego:
            break

        # Chuyển đổi sang ảnh xám (Grayscale) để tăng tốc độ tính toán
        # và phản ánh đúng bản chất thay đổi độ sáng
        gray_orig = cv2.cvtColor(frame_orig, cv2.COLOR_BGR2GRAY)
        gray_stego = cv2.cvtColor(frame_stego, cv2.COLOR_BGR2GRAY)

        # Tính PSNR cho frame hiện tại
        # Hàm tự động nhận diện kiểu dữ liệu uint8 có dải giá trị 0-255
        psnr_val = compare_psnr(gray_orig, gray_stego)
        total_psnr += psnr_val

        # Tính SSIM cho frame hiện tại
        ssim_val = compare_ssim(gray_orig, gray_stego, data_range=255)
        total_ssim += ssim_val

        frame_count += 1

    # Giải phóng bộ nhớ
    cap_orig.release()
    cap_stego.release()

    if frame_count == 0:
        print("Lỗi: Không đọc được khung hình nào từ video.")
        return 0, 0, 0

    # Tính trung bình cộng trên toàn bộ video
    avg_psnr = total_psnr / frame_count
    avg_ssim = total_ssim / frame_count

    return avg_psnr, avg_ssim, frame_count

if __name__ == "__main__":
    # Bạn có thể nhận tham số từ command line (sys.argv) để sinh viên dễ test
    # Ví dụ: python3 video_metrics.py cover.mp4 stego.mp4
    if len(sys.argv) != 3:
        print("Sử dụng: python3 video_metrics.py <video_goc.mp4> <video_giautin.mp4>")
        sys.exit(1)

    video_goc = sys.argv[1]
    video_giautin = sys.argv[2]

    print(f"Đang so sánh: '{video_goc}' và '{video_giautin}'")
    print("Quá trình này có thể mất vài phút tùy thuộc vào độ dài video...")
    
    avg_psnr, avg_ssim, frames = calculate_video_metrics(video_goc, video_giautin)

    if avg_psnr is not None:
        print("-" * 30)
        print("KẾT QUẢ ĐÁNH GIÁ:")
        print(f"Tổng số frames đã xử lý: {frames}")
        print(f"PSNR trung bình:         {avg_psnr:.2f} dB")
        print(f"SSIM trung bình:         {avg_ssim:.4f}")
        print("-" * 30)
