import cv2
import numpy as np
import sys
import os

def text_to_bits(filepath):
    """Đọc tệp văn bản và chuyển đổi thành chuỗi bit nhị phân."""
    if not os.path.exists(filepath):
        print(f"Lỗi: Không tìm thấy tệp {filepath}")
        sys.exit(1)
        
    with open(filepath, 'r', encoding='utf-8') as f:
        text = f.read()
    # Chuyển mỗi ký tự thành 8 bit
    bits = ''.join([format(ord(c), '08b') for c in text])
    return bits

def embed_dc(input_video, secret_file, output_video):
    """Nhúng chuỗi bit vào hệ số DC của video."""
    bits = text_to_bits(secret_file)
    bit_len = len(bits)
    bit_idx = 0

    cap = cv2.VideoCapture(input_video)
    if not cap.isOpened():
        print(f"Lỗi: Không thể mở video {input_video}")
        sys.exit(1)

    # Lấy thông số video gốc
    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    # Định dạng mp4v là phổ biến nhất cho OpenCV ghi MP4
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_video, fourcc, fps, (width, height))

    print(f"Bắt đầu nhúng {bit_len} bits từ '{secret_file}' vào '{input_video}'...")
    
    # Tham số lượng tử hóa cho hệ số DC. 
    # Delta càng lớn -> Dễ khôi phục nhưng PSNR càng giảm mạnh.
    delta = 16 

    while True:
        ret, frame = cap.read()
        if not ret:
            break # Hết video

        # Chỉ can thiệp nếu vẫn còn dữ liệu cần nhúng
        if bit_idx < bit_len:
            # Chuyển sang không gian màu YCrCb để tác động lên kênh Y (độ sáng)
            ycrcb = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
            Y, Cr, Cb = cv2.split(ycrcb)

            # Cắt lề để đảm bảo kích thước chia hết cho 8 (kích thước block DCT)
            h, w = Y.shape
            h_trunc = h - (h % 8)
            w_trunc = w - (w % 8)

            for i in range(0, h_trunc, 8):
                for j in range(0, w_trunc, 8):
                    if bit_idx >= bit_len:
                        break

                    # Trích xuất block 8x8 và chuyển đổi DCT
                    block = np.float32(Y[i:i+8, j:j+8])
                    dct_block = cv2.dct(block)

                    # --- Kỹ thuật sửa đổi hệ số DC ---
                    dc_val = dct_block[0, 0]
                    bit = int(bits[bit_idx])
                    
                    # Lượng tử hóa DC (QIM)
                    quantized = np.round(dc_val / delta) * delta
                    if bit == 1:
                        dct_block[0, 0] = quantized + (delta / 2)
                    else:
                        dct_block[0, 0] = quantized - (delta / 2)

                    bit_idx += 1

                    # IDCT và ghi đè lại block vào kênh Y
                    idct_block = cv2.idct(dct_block)
                    Y[i:i+8, j:j+8] = np.clip(idct_block, 0, 255)

            # Ghép lại các kênh và chuyển về BGR
            merged = cv2.merge([Y, Cr, Cb])
            frame = cv2.cvtColor(merged, cv2.COLOR_YCrCb2BGR)
        
        # Ghi frame (đã nhúng hoặc giữ nguyên) vào video mới
        out.write(frame)

    cap.release()
    out.release()

    print("-" * 40)
    if bit_idx < bit_len:
        print(f"CẢNH BÁO: Video quá ngắn! Chỉ nhúng được {bit_idx}/{bit_len} bits.")
        print("Hãy thử một video dài hơn hoặc tệp secret nhỏ hơn.")
    else:
        print(f"THÀNH CÔNG: Đã nhúng toàn bộ {bit_len} bits.")
        print(f"Video đầu ra đã được lưu tại: {output_video}")
    print("-" * 40)

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Cú pháp không hợp lệ!")
        print("Sử dụng: python3 stego_embed.py <video_goc.mp4> <file_secret.txt> <video_output.mp4>")
        sys.exit(1)
        
    embed_dc(sys.argv[1], sys.argv[2], sys.argv[3])
